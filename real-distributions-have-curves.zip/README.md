# TDSC-2
Fall'16 Tartan Data Science Cup
